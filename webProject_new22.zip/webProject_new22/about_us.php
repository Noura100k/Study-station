<?php 
$title = "about us";
include "header.php";
?>


<head>
	<title>about us</title>
	<link rel="stylesheet" type="text/css" href="css/aboutUs.css">


</head>

<body style="background-image: url(assets/background.png);">
	
	<main>
		<section class="idea">
	<p>The website (study station) is an educational website will help CCSIT students in their studying and face any difficulties in understanding in any subject. Sometimes, they don't understand something and even if they search, they don't get what they want. In our website will assign some people to help them and answer their question and explain what they don't understand.
• The website will let the students to choose instructors to provide assistant for them in any subjects.
• Our website will have three section each one represents one major and will have courses related with it and student can choose from them what they need.
• Each instructor will provide their information in their profile and some videos of them explaining some course so that the students can choose the instructor that can help them in understanding the course easily because each instructor has his/her way of explaining things.
• Each instructor will put the time that he/she is available, and the students can choose the time and how many hours do they need.
• The students will be able to meet instructors in person, the students will be able to get online lesson.
• Each instructor will provide demo lesson and based on that the student can make reservations.
• Students will give feedback about the instructor and if they were helpful or no.
• The website provides choice of payment such as apple pay and cash.
</p>

<div id="about">
	<div class="column center" id="column1">
		<img src="Assets/female.png"/>
		<br/>Hissah, validation on js , css for home page,about us, sign in/up pages (final virsion), html ( registration, login, cart, about us), php, mysql(database)


		
	</div>
	<div class="column center" id="column2">
		<img src="Assets/female.png"/>
		<br/>Nourah, html(homepage ,about us)subject page,help in payment page, add to cart page,booking information page, php, help on styling on css,mysql(database)
		
		
	</div>
	<div class="column center" id="column3">
		
		<img src="Assets/female.png"/>
		<br/>Latifah ( html, css, php (profile instructors and students , searching for teacher)), Save encrypted password, and verify it.
	
	</div>
	<div class="column center" id="column3">
	
		<img src="Assets/female.png"/>
		<br/>wed css , payment page ( php , html),thank you page
		
	</div>
	<div class="column center" id="column3">
		
		<img src="Assets/female.png"/>
		<br/>sarah css , payment page ( php , html),thank you page
		
	</div>
</div>


</main>


</body>

<?php include "footer.php" ?>


