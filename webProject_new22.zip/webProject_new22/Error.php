<?php 
$title = "Error ";
include "header.php";
echo "Sorry your payment is not completed , please try again !!!";
?>
<head>
        <h1>Problem</h1>
        <link rel="stylesheet" type="text/css" href="css\Error.css">
    </head>

    <body style="background-image: url(assets/background.png);">
    <br></br>
    <br></br>

    	</body>

