<!--  footer       --->

<footer>
		<div id="contact">
			<h4>Contact us</h4>
			<p>Call +966 555 888</p>
			<p>Email:studystation@gmail.com</p>

		</div>
		<div id="follow">
			<h4>Follow us</h4>
			<img src="assets/whatsapp.png"> <!--icons for social media-->
			<img src="assets/twitter.png">
			<img src="assets/instagram.png">
			
		</div>
       <p id="foot_text">studystation ©️ 2021</p>

	</footer>