<!DOCTYPE html>

<html>
	
 <head>
 	<title><?php echo $title; ?>-study station</title>
 	<link rel="stylesheet" type="text/css" href="css/homePage.css">
	 <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700" type="text/css">
 </head>

 <body>
 	
 	<div class="wrapper">

 	

       
   <header>

 	<img id="logo" src="assets/log.svg"/>	   


 	<nav>
 		<ul >
 			<a href="Home_page.php" style="text-decoration: none;" ><li>HOME</li></a>
			<a href="signUp_page.php" style="text-decoration: none;"><li>REGISTER</li></a>
			<a href="login_page.php" style="text-decoration: none;"><li>LOGIN</li></a> 
 			<a href="subject_page.php" style="text-decoration: none;  "><li>SUBJECTS</li></a>
			 
 			<a href="about_us.php" target="_blank" style="text-decoration: none; "><li>ABOUT US</li></a>

 		</ul>
 	</nav>

 	</header>	
</body>
</html>