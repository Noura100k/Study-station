<?php 
$title = "Thank you";
include "header.php";
echo "Thank you for choosing this site !";
?>
<head>
        <h1>Good Luck</h1>
        <link rel="stylesheet" type="text/css" href="css\thank_you.css">
    </head>

    <body style="background-image: url(assets/background.png);">
    <br></br>
    <br></br>

    	</body>

