<?php 
$title = " sign up";
include "header.php";
?>

    <head>
        <h1>Sign Up Page</h1>
        <link rel="stylesheet" type="text/css" href="css\signUp.css">
    </head>

    <body style="background-image: url(assets/background.png);">
        

          
           
                <div id="about">
                    <div class="column center" id="column1">
                        <a href="registeration_students.php">
                            <img src="Assets/student.png">
                            
                        <br/><br/>
                        <p>register as student</p>
                    </div>
                    <div class="column center" id="column2">
                        <a href="registeration_instructors.php">
                            <img src="Assets/instructor.png">
                            
                        <br/><br/>
                        <p>register as instructor</p>
                    </div>
                    </div>
                   
    </body>
<?php include  "footer.php" 
?>