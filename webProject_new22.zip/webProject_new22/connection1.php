<?php 
$host="localhost:3307";
$user="root";
$password="";
$db="study_station";

$con=mysqli_connect($host,$user,$password,$db);

?>
